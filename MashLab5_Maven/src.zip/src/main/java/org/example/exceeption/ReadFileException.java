package org.example.exceeption;

public class ReadFileException extends Exception{
    public ReadFileException(){
        super("Исключение для чтения файла");
    }
}
