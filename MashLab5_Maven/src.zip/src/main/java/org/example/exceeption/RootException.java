package org.example.exceeption;


public class RootException extends Exception{
    public RootException(String message){
        super(message );
    }
}
