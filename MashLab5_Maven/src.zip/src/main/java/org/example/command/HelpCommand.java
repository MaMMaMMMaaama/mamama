package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.system.Reciever;

public class HelpCommand implements BaseCommand{
    @Override
    public String execute(String[] args) throws WrongArgumentException {

        if (args.length == 1){
            Reciever.showHelp();
        } else throw new WrongArgumentException();
        return null;
    }

    @Override
    public String getName() {
        return "help";
    }

    @Override
    public String getDescription() {
        return "show all commands";
    }
}
