package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.system.Reciever;

public class ExecuteScriptCommand implements BaseCommand{
    @Override
    public String execute(String[] args) throws Exception {
        if (args.length == 2){
            Reciever.executeScript(args[1]);
        } else throw new WrongArgumentException();
        return null;
    }

    @Override
    public String getName() {
        return "execute_script";
    }

    @Override
    public String getDescription() {
        return  "execute_script_edition";
    }
}
