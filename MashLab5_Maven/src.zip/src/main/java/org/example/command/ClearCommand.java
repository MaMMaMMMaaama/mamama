package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.system.Reciever;

public class ClearCommand implements BaseCommand{
    @Override
    public String execute(String[] args) throws WrongArgumentException {
        if (args.length == 1){
            Reciever.clearCollection();
        } else throw new WrongArgumentException();
        return null;
    }

    @Override
    public String getName() {
        return "clear";
    }

    @Override
    public String getDescription() {
        return "clear collection";
    }
}
