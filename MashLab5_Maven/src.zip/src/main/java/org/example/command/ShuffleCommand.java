package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.managers.CollectionManager;
import org.example.recources.Worker;

import java.util.ArrayList;
import java.util.Collections;

public class ShuffleCommand implements BaseCommand{
    @Override
    public String execute(String[] args) throws Exception {
        ArrayList<Worker> list = CollectionManager.getWorkers() ;
        if (args.length ==1 ){
            Collections.shuffle(list);
            CollectionManager.setWorkers(list);
        }else throw new WrongArgumentException();
        return null;
    }

    @Override
    public String getName() {
        return "shuffle";
    }

    @Override
    public String getDescription() {
        return "shuffle_command";
    }
}
