package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.system.Reciever;

public class ShowCommand implements BaseCommand{
    @Override
    public String execute(String[] args) throws WrongArgumentException {
        if (args.length ==1 ){
            Reciever.showWorkers();

        }else throw new WrongArgumentException();
        return null;

    }

    @Override
    public String getName() {
        return "show";
    }

    @Override
    public String getDescription() {
        return "show workers";
    }
}
