package org.example.command;

import org.example.exceeption.WrongArgumentException;
import org.example.system.Reciever;

public class AddCommand implements BaseCommand{

    @Override
    public String execute(String[] args) throws WrongArgumentException {

        if (args.length == 1){
            Reciever.addNewWorker();
        } else throw new WrongArgumentException();
        return null;
    }

    @Override
    public String getName() {
        return "add";
    }

    @Override
    public String getDescription() {
        return "add new";
    }
}
