package org.example.recources;

public enum Color {
    GREEN,
    RED,
    WHITE,
    BROWN;
}

