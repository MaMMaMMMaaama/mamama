package org.example.recources;

public enum Country {
    RUSSIA,
    SPAIN,
    CHINA,
    ITALY;

}

