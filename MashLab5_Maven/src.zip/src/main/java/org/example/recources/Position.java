package org.example.recources;

public enum Position {
    MANAGER,
    HEAD_OF_DIVISION,
    DEVELOPER,
    LEAD_DEVELOPER;
}

