package org.example.recources;

public enum Status {
    FIRED,
    RECOMMENDED_FOR_PROMOTION,
    REGULAR;
}

